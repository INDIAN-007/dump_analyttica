
SET FOREIGN_KEY_CHECKS = 0;

-- Deleteing old data, if any

DELETE FROM r_chain_function_map WHERE function_id = 'FUNC0068';

DELETE FROM r_function_metadata WHERE function_id = 'FUNC0068';

DELETE FROM function_metadata WHERE function_id = 'FUNC0068';

DELETE FROM param WHERE function_id = 'FUNC0068';

DELETE FROM param_header WHERE function_id = 'FUNC0068';

DELETE FROM param_value WHERE function_id = 'FUNC0068';

DELETE FROM param_value_static_options WHERE function_id = 'FUNC0068';

DELETE FROM function_category_map WHERE function_id = 'FUNC0068';

-- End of Delete
  
  -- Start Data INSERT

INSERT INTO r_function_metadata (function_id,r_function_name,r_is_chain_function,function_language)Values('FUNC0068','RollupUpdated',False,'PYTHON');


INSERT INTO material (name,code) SELECT * FROM (SELECT 'Function - Roll Up', 'MAT_FUNC0068') as tmp WHERE NOT EXISTS ( SELECT id FROM material WHERE code = 'MAT_FUNC0068') LIMIT 1 ;

SET @FUNC_MATERIAL_ID = (SELECT id FROM material WHERE code = 'MAT_FUNC0068');


INSERT INTO function_metadata (function_id, function_name,is_active, is_executable, input_multitable_indicator, all_data_identifier, data_modify_indicator, new_column_indicator, new_datatable_indicator,output_type,create_data_object,use_data_object, function_desc, function_popup_title, function_popup_description, function_search_tags, material_id)Values('FUNC0068','Function - Roll Up',True,True,False,False,False,False,True,'CSV',False,False,'','','','50', @FUNC_MATERIAL_ID);


INSERT INTO function_category_map (Function_id, category_id) values('FUNC0068','404'); 
  -- Param 1);

INSERT INTO param (function_id, name, option_order, required, type, description, note, header, value)Values('FUNC0068','Function - Roll Up',2,False,'MULTI_SELECT','','Select this option only if all columns can be summarized using common set of summarization functions. Alternatively, select separate summarization functions below if they differ. Default option: "Sum"',9999,NULL);
   
INSERT INTO param_header (name, label, description, type, function_id, option_order)Values('rollUpFuncForAllColumns','Common summarization functions for selected colums','','STATIC','FUNC0068',2);

SET @Header_ID = (SELECT MAX(ID) FROM param_header);

SET @Function_ID = (SELECT function_id FROM param_header WHERE id = @Header_ID);

SET @Option_Order = (SELECT Option_Order FROM param_header WHERE id = @Header_ID);

UPDATE param SET header = @Header_ID WHERE function_id = @Function_ID AND Option_Order = @Option_Order;

  
INSERT INTO param_value (name, label, description, type, function_id, option_order)Values('rollUpFuncForAllColumns','Common summarization functions for selected colums','','STATIC','FUNC0068',2);

SET @Value_ID = (SELECT MAX(ID) FROM param_value);

SET @Function_ID = (SELECT function_id FROM param_value WHERE id = @Value_ID);

SET @Option_Order = (SELECT Option_Order FROM param_value WHERE id = @Value_ID);

UPDATE param SET value = @Value_ID WHERE function_id = @Function_ID AND Option_Order = @Option_Order;
    

INSERT INTO param_value_static_options (function_id, option_order, name, label)Values('FUNC0068', 2, 'Count Distinct', 'Count Distinct');



INSERT INTO param_value_static_options (function_id, option_order, name, label)Values('FUNC0068', 2, 'Min', 'Minimum');



INSERT INTO param_value_static_options (function_id, option_order, name, label)Values('FUNC0068', 2, 'Max', 'Maximum');



INSERT INTO param_value_static_options (function_id, option_order, name, label)Values('FUNC0068', 2, 'Mode', 'Mode');



INSERT INTO param_value_static_options (function_id, option_order, name, label)Values('FUNC0068', 2, 'Median', 'Median');



INSERT INTO param_value_static_options (function_id, option_order, name, label)Values('FUNC0068', 2, 'Avg', 'Average');



INSERT INTO param_value_static_options (function_id, option_order, name, label)Values('FUNC0068', 2, 'Count', 'Count');



INSERT INTO param_value_static_options (function_id, option_order, name, label)Values('FUNC0068', 2, 'Sum', 'Sum');



INSERT INTO param_value_static_options (function_id, option_order, name, label)Values('FUNC0068', 2, 'variance', 'Variance');

 
  -- Param 2);

INSERT INTO param (function_id, name, option_order, required, type, description, note, header, value)Values('FUNC0068','Function - Roll Up',1,True,'MULTI_SELECT','','',9999,NULL);
   
INSERT INTO param_header (name, label, description, type, function_id, option_order)Values('Group_By','Group By','','STATIC','FUNC0068',1);

SET @Header_ID = (SELECT MAX(ID) FROM param_header);

SET @Function_ID = (SELECT function_id FROM param_header WHERE id = @Header_ID);

SET @Option_Order = (SELECT Option_Order FROM param_header WHERE id = @Header_ID);

UPDATE param SET header = @Header_ID WHERE function_id = @Function_ID AND Option_Order = @Option_Order;

  
INSERT INTO param_value (name, label, description, type, function_id, option_order)Values('ROLL UP VALUE','','','DATA_HEADER','FUNC0068',1);

SET @Value_ID = (SELECT MAX(ID) FROM param_value);

SET @Function_ID = (SELECT function_id FROM param_value WHERE id = @Value_ID);

SET @Option_Order = (SELECT Option_Order FROM param_value WHERE id = @Value_ID);

UPDATE param SET value = @Value_ID WHERE function_id = @Function_ID AND Option_Order = @Option_Order;
     
  -- Param 3);

INSERT INTO param (function_id, name, option_order, required, type, description, note, header, value)Values('FUNC0068','Function - Roll Up',3,False,'MULTI_SELECT','','Select summarization functions for specified column. Deafault option: "Sum" ',9999,NULL);
   
INSERT INTO param_header (name, label, description, type, function_id, option_order)Values('ROLL UP','ROLL UP','','DATA_HEADER','FUNC0068',3);

SET @Header_ID = (SELECT MAX(ID) FROM param_header);

SET @Function_ID = (SELECT function_id FROM param_header WHERE id = @Header_ID);

SET @Option_Order = (SELECT Option_Order FROM param_header WHERE id = @Header_ID);

UPDATE param SET header = @Header_ID WHERE function_id = @Function_ID AND Option_Order = @Option_Order;

  
INSERT INTO param_value (name, label, description, type, function_id, option_order)Values('ROLL UP VALUE','','','STATIC','FUNC0068',3);

SET @Value_ID = (SELECT MAX(ID) FROM param_value);

SET @Function_ID = (SELECT function_id FROM param_value WHERE id = @Value_ID);

SET @Option_Order = (SELECT Option_Order FROM param_value WHERE id = @Value_ID);

UPDATE param SET value = @Value_ID WHERE function_id = @Function_ID AND Option_Order = @Option_Order;
    

INSERT INTO param_value_static_options (function_id, option_order, name, label)Values('FUNC0068', 3, 'Count Distinct', 'Count Distinct');



INSERT INTO param_value_static_options (function_id, option_order, name, label)Values('FUNC0068', 3, 'Min', 'Minimum');



INSERT INTO param_value_static_options (function_id, option_order, name, label)Values('FUNC0068', 3, 'Max', 'Maximum');



INSERT INTO param_value_static_options (function_id, option_order, name, label)Values('FUNC0068', 3, 'Mode', 'Mode');



INSERT INTO param_value_static_options (function_id, option_order, name, label)Values('FUNC0068', 3, 'Median', 'Median');



INSERT INTO param_value_static_options (function_id, option_order, name, label)Values('FUNC0068', 3, 'Avg', 'Average');



INSERT INTO param_value_static_options (function_id, option_order, name, label)Values('FUNC0068', 3, 'Count', 'Count');



INSERT INTO param_value_static_options (function_id, option_order, name, label)Values('FUNC0068', 3, 'Sum', 'Sum');



INSERT INTO param_value_static_options (function_id, option_order, name, label)Values('FUNC0068', 3, 'variance', 'Variance');


UPDATE param_value_static_options

SET value_id = (SELECT id

FROM param_value

WHERE param_value.function_id = param_value_static_options.function_id

AND param_value.option_order = param_value_static_options.option_order )

WHERE function_id = 'FUNC0068';


SET FOREIGN_KEY_CHECKS= 1 ;
  