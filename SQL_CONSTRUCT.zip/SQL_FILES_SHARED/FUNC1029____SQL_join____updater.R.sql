FUNC1029____SQL_join____updater.R.sql

-- ------------------------------------------------------------------------------------------------------

 

 

SET FOREIGN_KEY_CHECKS = 0;

 

-- Deleteing old data, if any

DELETE FROM r_chain_function_map WHERE function_id = 'FUNC1029';

DELETE FROM r_function_metadata WHERE function_id = 'FUNC1029';

DELETE FROM function_metadata WHERE function_id = 'FUNC1029';

DELETE FROM param WHERE function_id = 'FUNC1029';

DELETE FROM param_header WHERE function_id = 'FUNC1029';

DELETE FROM param_value WHERE function_id = 'FUNC1029';

DELETE FROM param_value_static_options WHERE function_id = 'FUNC1029';

DELETE FROM function_category_map WHERE function_id = 'FUNC1029';

-- End of Delete

 

-- Start Data INSERT

INSERT INTO r_function_metadata (function_id,r_function_name,r_is_chain_function,function_language)Values('FUNC1029','SQL_join',False,'PYTHON');

 

INSERT INTO material (name,code) SELECT * FROM (SELECT 'Function -` SQL Join', 'MAT_FUNC1029') as tmp WHERE NOT EXISTS ( SELECT id FROM material WHERE code = 'MAT_FUNC1029') LIMIT 1 ;

SET @FUNC_MATERIAL_ID = (SELECT id FROM material WHERE code = 'MAT_FUNC1029');

 

INSERT INTO function_metadata (function_id, function_name,is_active, is_executable, input_multitable_indicator, all_data_identifier, data_modify_indicator, new_column_indicator, new_datatable_indicator,use_data_object,create_data_object,output_type, function_desc, function_popup_title, function_popup_description, function_search_tags, material_id)Values
                                                                ('FUNC1029','SQL Join',True,True,True,False,False,False,True,False,False,'MIXED_OUTPUT','','','','sql,joi,join', @FUNC_MATERIAL_ID);

 

INSERT INTO function_category_map (Function_id, category_id) values('FUNC1029','107');

 

-- Param 1);

INSERT INTO param (function_id, name, option_order, required, type, description, note, header, value)Values('FUNC1029','SQL Join',1,True,'MULTI_SELECT','','Select column(s) to display from left table',9999,NULL);

 

INSERT INTO param_header (name, label, description, type, function_id, option_order)Values('table1','Select the left table and the columns to join on','','DATA_TABLE','FUNC1029',1);

SET @Header_ID = (SELECT MAX(ID) FROM param_header);

SET @Function_ID = (SELECT function_id FROM param_header WHERE id = @Header_ID);

SET @Option_Order = (SELECT Option_Order FROM param_header WHERE id = @Header_ID);

UPDATE param SET header =  @Header_ID WHERE function_id = @Function_ID AND Option_Order = @Option_Order;

 

INSERT INTO param_value (name, label, description, type, function_id, option_order)Values('table1','Select the left table and the columns to join on','','DATA_HEADER','FUNC1029',1);

SET @Value_ID = (SELECT MAX(ID) FROM param_value);

SET @Function_ID = (SELECT function_id FROM param_value WHERE id = @Value_ID);

SET @Option_Order = (SELECT Option_Order FROM param_value WHERE id = @Value_ID);

UPDATE param SET value =  @Value_ID WHERE function_id = @Function_ID AND Option_Order = @Option_Order;

 



-- Param 2);

INSERT INTO param (function_id, name, option_order, required, type, description, note, header, value)Values('FUNC1029','SQL Join',2,True,'MULTI_SELECT','','Select column(s) to display from right table',9999,NULL);

 

INSERT INTO param_header (name, label, description, type, function_id, option_order)Values('table2','Select the right table and the columns to join on','','DATA_TABLE','FUNC1029',2);

SET @Header_ID = (SELECT MAX(ID) FROM param_header);

SET @Function_ID = (SELECT function_id FROM param_header WHERE id = @Header_ID);

SET @Option_Order = (SELECT Option_Order FROM param_header WHERE id = @Header_ID);

UPDATE param SET header =  @Header_ID WHERE function_id = @Function_ID AND Option_Order = @Option_Order;

 

INSERT INTO param_value (name, label, description, type, function_id, option_order)Values('table2','Select the right table and the columns to join on','','DATA_HEADER','FUNC1029',2);

SET @Value_ID = (SELECT MAX(ID) FROM param_value);

SET @Function_ID = (SELECT function_id FROM param_value WHERE id = @Value_ID);

SET @Option_Order = (SELECT Option_Order FROM param_value WHERE id = @Value_ID);

UPDATE param SET value =  @Value_ID WHERE function_id = @Function_ID AND Option_Order = @Option_Order;

 



-- Param 3);

INSERT INTO param (function_id, name, option_order, required, type, description, note, header, value)Values('FUNC1029','SQL Join',3,False,'SINGLE_SELECT','','Select the type of join to be used; Default value is INNER',9999,NULL);

 

INSERT INTO param_header (name, label, description, type, function_id, option_order)Values('join_type','Join Type','','STATIC','FUNC1029',3);

SET @Header_ID = (SELECT MAX(ID) FROM param_header);

SET @Function_ID = (SELECT function_id FROM param_header WHERE id = @Header_ID);

SET @Option_Order = (SELECT Option_Order FROM param_header WHERE id = @Header_ID);

UPDATE param SET header =  @Header_ID WHERE function_id = @Function_ID AND Option_Order = @Option_Order;

 

INSERT INTO param_value (name, label, description, type, function_id, option_order)Values('join_type','Join Type','','STATIC','FUNC1029',3);

SET @Value_ID = (SELECT MAX(ID) FROM param_value);

SET @Function_ID = (SELECT function_id FROM param_value WHERE id = @Value_ID);

SET @Option_Order = (SELECT Option_Order FROM param_value WHERE id = @Value_ID);

UPDATE param SET value =  @Value_ID WHERE function_id = @Function_ID AND Option_Order = @Option_Order;

 



-- Param 4);

INSERT INTO param (function_id, name, option_order, required, type, description, note, header, value)Values('FUNC1029','SQL Join',4,True,'MULTI_SELECT','','Select a column common to both tables.',9999,NULL);

 

INSERT INTO param_header (name, label, description, type, function_id, option_order)Values('common_table','Common column','','DATA_TABLE','FUNC1029',4);

SET @Header_ID = (SELECT MAX(ID) FROM param_header);

SET @Function_ID = (SELECT function_id FROM param_header WHERE id = @Header_ID);

SET @Option_Order = (SELECT Option_Order FROM param_header WHERE id = @Header_ID);

UPDATE param SET header =  @Header_ID WHERE function_id = @Function_ID AND Option_Order = @Option_Order;

 

INSERT INTO param_value (name, label, description, type, function_id, option_order)Values('common_table','Common column','','DATA_HEADER','FUNC1029',4);

SET @Value_ID = (SELECT MAX(ID) FROM param_value);

SET @Function_ID = (SELECT function_id FROM param_value WHERE id = @Value_ID);

SET @Option_Order = (SELECT Option_Order FROM param_value WHERE id = @Value_ID);

UPDATE param SET value =  @Value_ID WHERE function_id = @Function_ID AND Option_Order = @Option_Order;

 



INSERT INTO param_value_static_options (function_id, option_order, name, label)Values('FUNC1029',3,'LEFT','LEFT');

INSERT INTO param_value_static_options (function_id, option_order, name, label)Values('FUNC1029',3,'INNER','INNER');

 

UPDATE param_value_static_options

SET value_id = (SELECT id

            FROM param_value

            WHERE param_value.function_id = param_value_static_options.function_id

            AND param_value.option_order = param_value_static_options.option_order )

WHERE function_id = 'FUNC1029';

 

SET FOREIGN_KEY_CHECKS= 1 ;
