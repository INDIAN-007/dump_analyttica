// import React from 'react'
// import PlotlyEditor from 'react-chart-editor';
import json_ from './json_plotly/json_plotly_testing/image_mari.json'
// import plotly from 'plotly.js/dist/plotly';
// import 'react-chart-editor/lib/react-chart-editor.css';

// const config = {editable: true};
// export default function App() {

//   return (
//          <div className="app">
//         <PlotlyEditor
//           data={json_["data"]}
//           layout={json_["layout"]}
//           config={config}
//           // frames={this.state.frames}
//           // dataSources={dataSources}
//           // dataSourceOptions={dataSourceOptions}
//           plotly={plotly}
//           // onUpdate={(data, layout, frames) => this.setState({data, layout, frames})}
//           // useResizeHandler
//           debug
//           advancedTraceTypeSelector
//         />
//       </div>
//   )
// }


import React, {Component, useState} from 'react';
import plotly from 'plotly.js/dist/plotly';
import PlotlyEditor from 'react-chart-editor';
import 'react-chart-editor/lib/react-chart-editor.css';
import DataFrame from 'dataframe-js';
// import DataFrame, { Row } from 'dataframe-js';

console.log(json_)
DataFrame.fromCSV('http://myurl/myfile.csv').then(df => df);
// console.log(df)

const dataSources = {
  col1: [1, 2, 3], // eslint-disable-line no-magic-numbers
  col2: [4, 3, 2], // eslint-disable-line no-magic-numbers
  col3: [17, 13, 9], // eslint-disable-line no-magic-numbers
};

const dataSourceOptions = Object.keys(dataSources).map((name) => ({
  value: name,
  label: name,
}));

const config = {editable: true};

export default function App() {
  // constructor() {
  //   super();
  //   this.state = {data: [], layout: {}, frames: []};
  // }

  // const [state,setState]=useState({data:[],layout:{},frames:[]})
  const [state,setState]=useState({data:json_["data"],layout:json_["layout"],frames:[]})

    return (
      <div className="app">
        <PlotlyEditor
          data={state.data}
          layout={state.layout}
          config={config}
          frames={state.frames}
          dataSources={dataSources}
          dataSourceOptions={dataSourceOptions}
          plotly={plotly}
          onUpdate={(data, layout, frames) => setState({data, layout, frames})}
          useResizeHandler
          debug
          advancedTraceTypeSelector
        />
      </div>
    );
  }

