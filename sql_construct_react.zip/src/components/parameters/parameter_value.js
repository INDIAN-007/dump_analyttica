import React from 'react'

const ParameterValue = (props) => {
  return (
    <div>Parameter Value</div>
  )
}

export default ParameterValue