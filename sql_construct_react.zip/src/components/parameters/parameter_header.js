import React from 'react'
import { parameter,param_header,parameter_value } from '../../static/parameters'

const ParameterHeader = (props) => {
  return (
    <div>Parameter Header</div>
  )
}

export default ParameterHeader