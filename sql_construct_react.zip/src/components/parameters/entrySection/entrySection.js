import React from 'react'

const EntrySection = (props) => {
  return (
    <div><input type="text" /></div>
  )
}

export default EntrySection