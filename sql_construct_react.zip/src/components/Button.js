import React from 'react'

const Button = (props) => {
  return (
    <>
    <div className='button-1' >
    {props.name}
    </div>
    </>
  )
}

export default Button