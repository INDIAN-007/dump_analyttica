import React from 'react';
import './App.css';
import Plot from 'react-plotly.js';
// import json_ from "./json_plotly/scatter_data_label.json"
// import json_ from "./json_plotly/bar_chart_color_bg.json"
// import json_ from "./json_plotly/json_plotly_testing/spark_line_chart_plotly.json"
import RotateRightIcon from '@mui/icons-material/RotateRight';
import RotateLeftIcon from '@mui/icons-material/RotateLeft';
import json_ from "./json_plotly/json_plotly_testing/image_stacked_area_chart_plotly.json"
// import json_ from "./json_plotly/bar_plot_04_01.json"
// import json_ from "./json_plotly/bar_plot_jan_5.json"
// import json_ from './json_plotly/bar_chart_modified.json'
import Forward30Icon from '@mui/icons-material/Forward30';
import TextField from '@mui/material/TextField';

import { useState } from 'react';
import Switch from '@mui/material/Switch';

import { HexColorPicker } from "react-colorful";
import { Checkbox, FormControlLabel, FormGroup } from '@mui/material';
import { SketchPicker } from 'react-color'
import data_frame from "./json_plotly/df.json"
// import JSON

function App() {

  console.log(data_frame,"Printing Data Frame")
  console.log(json_,"printing json normal")
  // plot_bgcolor
  json_['layout']["xaxis"]={
    "showgrid":true
  }
  json_['layout']["yaxis"]={
    "showgrid":true
  }
  // json_["layout"]["template"]['layout']["paper_bgcolor"]
  // json_["layout"]["template"]['layout']["plot_bgcolor"]
  const list_of_color_section=["pg_bgcolor","plot_bgcolor","title","headingTitle"]
  // json_["data"][0]["visible"]= [true]
  const [data,setdata]=useState(json_["data"])
  let lay=json_['layout']
  // lay["clickmode"]="select"
  const [layout,setlayout]=useState(lay)
  // const [layout,setlayout]=useState(json_["layout"])
  const [showDatalabel,setShowDatalabel]=useState(true)
  // const [config,setConfig]=useState(json_["config"])
  // const [setsection,selectsetsection]=useState()
  const [color_bg,setColor_bg]=useState("#fff")
  const [text,setText]=useState(json_["data"][0]["text"])


  console.log(layout)
  console.log(data)
  console.log(layout["template"]['layout']["paper_bgcolor"])

  const handleChangeComplete=(color)=>{
    console.log(color.hex)
    let new_data=data
  for (let i in new_data){
    console.log("Printing Data array",new_data[i])
    new_data[i].textfont={color:color.hex}
  }
  setdata(new_data)
    setColor_bg(color.hex)
  }

  const onchangeVgid=(e)=>{
    console.log(e)
    let h=layout
    h['xaxis']["showgrid"]= !layout['xaxis']["showgrid"]
    console.log(h)
    setlayout({...h})
}

const onchangeHgid=(e)=>{
  console.log(e)
  let h=layout
  h['yaxis']["showgrid"]= !layout['yaxis']["showgrid"]
  console.log(h)
  setlayout({...h})
}
const config={
  "scrollZoom":true,
  "editable":true,
  'modeBarButtonsToAdd': ['drawline',
  'drawopenpath',
  'drawclosedpath',
  'drawcircle',
  'drawrect',
  'eraseshape',
  "resetViewMapbox"

  ]

}
  const[xinterval,setXInterval]=useState("")
  const[yinterval,setYInterval]=useState("")
const changeXInterval=(e)=>{
  console.log(e.target.value)
  setXInterval(e.target.value)
  if (e.target.value===""){
    let h = layout
    delete h["xaxis"]['dtick']
    setlayout({...h})
  }else{
    let h = layout
    h["xaxis"]['dtick']=parseFloat(e.target.value)
    console.log(h['xaxis'],"prinrting")
    setlayout({...h})
  }
}


const changeYInterval=(e)=>{
  console.log(e.target.value)
  setYInterval(e.target.value)
  if (e.target.value===""){
    let h = layout
    delete h["yaxis"]['dtick']
    setlayout({...h})
  }else{
    let h = layout
    h["yaxis"]['dtick']=parseFloat(e.target.value)
    console.log(h['yaxis'],"prinrting")
    setlayout({...h})
  }
}

const toggleDataLabel=(e)=>{
  let dummy=data
  console.log(text)
  if (!showDatalabel){
    // console.log("Setting Data")
    // dummy[0]['text']=text
    for (let i in data){
      delete data[i]["textfont"]
    }
  }else{
    // dummy[0]["text"]=[]
    for (let i in data){
      data[i]["textfont"]={
        color:"rgba(60,60,60,0)"
      }
    }
  }

  // for (let i in data){
  //   data[i]["textfont"]={
  //     color:"rgba(60,60,60,0)"
  //   }
  // }


  console.log(showDatalabel)
  setShowDatalabel(!showDatalabel)
  setdata(dummy)
 
}

const rotateLabelClockWise=()=>{
  if (layout.xaxis.hasOwnProperty("tickangle")){
    console.log("It has Property")
    let lay_=layout
    lay_.xaxis.tickangle+=30
    setlayout({...lay_})
    console.log(layout)
  }else{
    console.log("It does not have ")
    let lay_=layout
    lay_.xaxis.tickangle=30
    setlayout({...lay_})
    console.log(layout)
  }

}

const rotateLabelantiClockWise=()=>{
  if (layout.xaxis.hasOwnProperty("tickangle")){
    console.log("It has Property")
    let lay_=layout
    lay_.xaxis.tickangle-=30
    setlayout({...lay_})
    console.log(layout)
  }else{
    console.log("It does not have ")
    let lay_=layout
    lay_.xaxis.tickangle=360-30
    setlayout({...lay_})
    console.log(layout)
  }

}



  return (
    <div className="App">
      <div className="App-header">
      <div>
      <Switch onChange={onchangeVgid} checked={layout["xaxis"]["showgrid"]} />
      <Switch onChange={onchangeHgid} checked={layout["yaxis"]["showgrid"]} />
      <Switch onChange={toggleDataLabel} checked={showDatalabel} />
      </div>
            <Plot
        data={data}
        layout={layout}
        config={config}

      />
      <div>
      <RotateRightIcon color="secondary" onClick={rotateLabelClockWise}/>
      <RotateLeftIcon color="secondary" onClick={rotateLabelantiClockWise}/>
      <TextField id="outlined-basic" label="Xaxis" variant="filled" value={xinterval} onChange={changeXInterval}/>
      <TextField id="outlined-basic" label="Yaxis" variant="filled" value={yinterval} onChange={changeYInterval}/>
      

      </div>
      <div className='color-picker-section' style={{"display":"flex"}}  >
      <SketchPicker  
              color={ color_bg }
              onChange={ handleChangeComplete }
      />     
      <FormGroup onChange={(e)=>{console.log(e)}} >
  <FormControlLabel control={<Checkbox defaultChecked />} label="Page Bg Color" />
  <FormControlLabel  control={<Checkbox />} label="Plot BG Color" />
  <FormControlLabel  control={<Checkbox />} label="Title Color" />
  <FormControlLabel  control={<Checkbox />} label="Font Color" />
</FormGroup>   
      </div>
      </div>
    </div>
  );
}

export default App;
