import React from 'react'

const Plotly_P  = (props) => {

    // var myPlot = document.getElementById('mygraph')
    // Plotly.newPlot("mygraph",props.data,props.layout)
  return (
    <div id="mygraph" >
    </div>
  )
}

export default Plotly_P